#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <thread>
#include <chrono>
#include <omp.h>
#include <fstream>
#include <atomic>
#include <ctime> // Required for CPU utilization tracking

// --- 1. Sequential ---
bool is_sorted_sequential(const std::vector<int>& data) {
    asm volatile("" : : "g"(data.data()) : "memory");
    for (size_t i = 0; i < data.size() - 1; ++i) {
        if (data[i] > data[i+1]) return false;
    }
    return true;
}

// --- 2. Manual Threads ---
bool is_sorted_threads(const std::vector<int>& data) {
    size_t n = data.size();
    if (n < 2) return true;
    unsigned int num_threads = std::thread::hardware_concurrency();
    std::vector<std::thread> workers;
    std::atomic<bool> sorted{true};
    size_t chunk = n / num_threads;

    for (unsigned int t = 0; t < num_threads; ++t) {
        workers.emplace_back([&, t]() {
            size_t start = t * chunk;
            size_t end = (t == num_threads - 1) ? n - 1 : (t + 1) * chunk;
            for (size_t i = start; i < end; ++i) {
                if (!sorted.load(std::memory_order_relaxed)) return;
                if (data[i] > data[i+1]) { sorted = false; return; }
            }
        });
    }
    for (auto& w : workers) w.join();
    return sorted;
}

// --- 3. OpenMP Static ---
bool is_sorted_omp_static(const std::vector<int>& data) {
    bool sorted = true;
    #pragma omp parallel for shared(sorted) schedule(static)
    for (size_t i = 0; i < (size_t)data.size() - 1; ++i) {
        if (!sorted) continue;
        if (data[i] > data[i+1]) sorted = false;
    }
    return sorted;
}

// --- 4. OpenMP Dynamic ---
bool is_sorted_omp_dynamic(const std::vector<int>& data) {
    bool sorted = true;
    #pragma omp parallel for shared(sorted) schedule(dynamic, 10000)
    for (size_t i = 0; i < (size_t)data.size() - 1; ++i) {
        if (!sorted) continue;
        if (data[i] > data[i+1]) sorted = false;
    }
    return sorted;
}

int main() {
    // Increased sizes to make CPU utilization measurable. 
    // Small sizes finish too fast for the OS to report accurate CPU usage.
    std::vector<size_t> sizes = {1000000, 10000000, 50000000, 100000000};
    std::ofstream file("results.csv");
    
    // Header for our two graphs
    file << "Size,Method,Time_us,CPU_Utilization_Pct\n";

    std::cout << "Starting Benchmarks..." << std::endl;

    for (size_t n : sizes) {
        std::vector<int> data(n);
        std::iota(data.begin(), data.end(), 0); // Fill with sorted data

        auto run_bench = [&](std::string name, auto func) {
            // Clock Time (Sum of all core activity)
            std::clock_t cpu_start = std::clock();
            // Wall Time (Real world time)
            auto wall_start = std::chrono::high_resolution_clock::now();

            volatile bool result = func(data);

            auto wall_end = std::chrono::high_resolution_clock::now();
            std::clock_t cpu_end = std::clock();

            // Calculations
            double wall_time_us = std::chrono::duration<double, std::micro>(wall_end - wall_start).count();
            double cpu_time_us = 1000000.0 * (cpu_end - cpu_start) / CLOCKS_PER_SEC;
            
            // Utilization = (CPU time / Wall time) * 100
            // Sequential should be ~100%, Parallel should be ~800% (on 8 cores)
            double utilization = (cpu_time_us / wall_time_us) * 100.0;

            file << n << "," << name << "," << wall_time_us << "," << utilization << "\n";
            std::cout << "Size: " << n << " | " << name 
                      << " | Time: " << wall_time_us << " us" 
                      << " | CPU: " << (int)utilization << "%" << std::endl;
        };

        run_bench("Sequential", is_sorted_sequential);
        run_bench("Threads", is_sorted_threads);
        run_bench("OpenMP_Static", is_sorted_omp_static);
        run_bench("OpenMP_Dynamic", is_sorted_omp_dynamic);
        std::cout << "----------------------------------------------------" << std::endl;
    }

    file.close();
    std::cout << "Data saved to results.csv" << std::endl;
    return 0;
}
